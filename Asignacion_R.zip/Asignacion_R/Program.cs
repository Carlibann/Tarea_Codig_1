﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asignacion_R
{
    internal class Program
    {
        static int[] datosN;
        static string n2 = "";
        static bool menu = true;
        static void Main(string[] args)
        {
            //Enunciado: Dado un arreglo de números enteros, escribe un programa que cuente cuántos elementos son positivos y cuántos son negativos.
            //Enunciado: Dado un arreglo de números enteros, escribe un programa que calcule y devuelva el promedio de los elementos que son números pares.
            //Enunciado: Dado un arreglo de números enteros, escribe un programa que calcule y devuelva el producto de todos los elementos del arreglo.
            //Enunciado: Dado un arreglo de números enteros y un número específico, escribe un programa que cuente cuántas veces aparece ese número específico en el arreglo.

            while (menu)
            {
                int opcc;

                Console.WriteLine("#######################################");
                Console.WriteLine("            Menu de algoritmos         ");
                Console.WriteLine("#######################################");
                Console.WriteLine(" [1]. Insertar datos");
                Console.WriteLine(" [2]. Arreglo que cuenta positvo y negativo");
                Console.WriteLine(" [3]. Arreglo promedio num pares ");
                Console.WriteLine(" [4]. Calcular devolver productos  ");
                Console.WriteLine(" [5]. Mostrar resultados de todos los datos del arreglo");
                Console.WriteLine(" [6]. Salir                     ");
                Console.WriteLine("#######################################");
                Console.WriteLine("Selecione una opcion del menu");
                opcc = int.Parse(Console.ReadLine());

                switch (opcc)
                {
                    case 1:
                        insertarDatos();
                        repetirMenu();
                        break;
                    case 2:
                        arregloDeNumerosPositivos();
                        repetirMenu();
                        break;

                    case 3:
                        promedioNumPares();
                        repetirMenu();
                        break;

                    case 4:
                        numeroEnArreglo();
                        repetirMenu();
                        break;
                    case 5:
                        mostrarDatosArreglo();
                        repetirMenu();
                        break;
                    case 6:
                        menu = false;
                        Console.WriteLine("Presione ENTER para continuar");
                        break;

                    default:
                        Console.WriteLine("Ingrese una opcion valida..");
                        repetirMenu();
                        break;


                }
                Console.ReadKey();
            }
        }

        static void insertarDatos()
        {

            Console.WriteLine("Ingrese la cantidad de datos a ingresar");
            int num = int.Parse(Console.ReadLine());

            datosN = new int[num];

            for (int i = 0; i < num; i++)
            {
                Console.WriteLine($"ingrese el valor de la posicion [{i}]]: ");
                int valor = int.Parse(Console.ReadLine());
                datosN[i] = valor;
                Console.WriteLine(datosN[i]);
            }



        }

        static void arregloDeNumerosPositivos()
        {
            int positivo = 0;
            int negativo = 0;

            for (int i = 0; i < datosN.Length; i++)
            {
                if (datosN[i] > 0)
                {
                    positivo++;
                }
                else if (datosN[i] < 0)
                {
                    negativo++;
                }
            }

            Console.WriteLine($"Se contaron {positivo}, positivos");
            Console.WriteLine($"Se contaron {negativo}, negativos");

        }

        static void promedioNumPares()
        {

            int contar = 0;
            double suma = 0;
            double promedio = 0;

            for (int i = 0; i < datosN.Length; i++)
            {
                if (datosN[i] % 2 == 0)
                {
                    suma += datosN[i];
                    contar++;
                }

            }

            if (contar > 0)
            {
                promedio = (double)suma / datosN.Length;
                Console.WriteLine($"El promedio de numeros pares es de {promedio}");
            }
            else
            {
                Console.WriteLine("No se encrontraron numeros pares");
            }



        }

        static void mostrarDatosArreglo()
        {
            Console.WriteLine("Datos guardados en el arreglo");

            for (int i = 0; i < datosN.Length; i++)
            {
                Console.WriteLine($"Producto [{i}] --> {datosN[i]}");
            }
        }

        static void numeroEnArreglo()
        {
            int contador = 0;
            int buscar;

            Console.WriteLine("Ingrese el numero a buscar");
            buscar = int.Parse(Console.ReadLine());

            for (int i = 0; i < datosN.Length; i++)
            {
                if (datosN[i].Equals(buscar))
                {
                    contador++;
                }
            }

            Console.WriteLine($"El numero buscado aparece {contador}, veces.");
        }

        static void repetirMenu()
        {

            Console.WriteLine("Ingrese [Y] para continuar [N] para salir");
            n2 = Console.ReadLine();
            if (n2 == "Y" || n2 == "y")
            {
                Console.Clear();
                Console.WriteLine("Presione ENTER para continuar");
                menu = true;

            }
            else if (n2 == "N" || n2 == "n")
            {
                Console.Clear();
                Console.WriteLine("Presione ENTER para continuar");
                menu = false;
            }
            else
            {
                Console.WriteLine("Ingrese una opcion validad");
                Console.WriteLine("Presione ENTER para continuar");
                menu = false;
            }

        }



    }
}
